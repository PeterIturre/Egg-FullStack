/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comparadores;

import java.util.Comparator;

/**
 *
 * @author Digital
 */
public class Comparador {
    public static Comparator<String> ordenarPaisesAsc = new Comparator<String>() {
        @Override
        public int compare(String t, String t1) {
            return t.compareTo(t1);
        }
        
    };
    
    public static Comparator<String> ordenarPaisesDesc = new Comparator<String>() {
        @Override
        public int compare(String t, String t1) {
            return t1.compareTo(t);
        }
        
    };
    
    
}
