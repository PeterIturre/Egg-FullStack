package eje2guia12;

import entidades.Electrodomesticos;
import entidades.Lavadora;
import entidades.Televisor;
import java.util.ArrayList;

public class Eje2guia12 {

    public static void main(String[] args) {

        ArrayList<Electrodomesticos> electrodomesticos = new ArrayList();

        //   Lavadora lavadora = new Lavadora();
        // lavadora.crearLavadora();
        // System.out.println("Precio final de la lavadora: $" + lavadora.precioFinal());
//        Televisor televisor = new Televisor();
        //      televisor.crearTelevisor();
        //    System.out.println("Precio final del televisor: $" + televisor.precioFinal());
        Electrodomesticos lavadora1 = new Lavadora(31, 1000, "negro", 'A', 80);
        Electrodomesticos lavadora2 = new Lavadora(30, 1000, "negro", 'B', 50);
        Electrodomesticos televisor3 = new Televisor(40, true, 1000, "blanco", 'C', 70);
        Electrodomesticos televisor4 = new Televisor(45, true, 1000, "blanco", 'F', 60);

        electrodomesticos.add(lavadora1);
        
        electrodomesticos.add(televisor3);

        electrodomesticos.add(televisor4);

        electrodomesticos.add(lavadora2);

        double precioTotalElectrodomesticos = 0;
        double precioTotalLavadoras = 0;
        double precioTotalTelevisores = 0;

        for (Electrodomesticos electrodomestico : electrodomesticos) {
            double precioFinal = electrodomestico.precioFinal();
            precioTotalElectrodomesticos += precioFinal;

            if (electrodomestico instanceof Lavadora) {
                precioTotalLavadoras += precioFinal;
                continue;
            }
            if (electrodomestico instanceof Televisor) {
                precioTotalTelevisores += precioFinal;

            }
        }

        System.out.println(
                "Precio total de los televisores: " + precioTotalTelevisores);
        System.out.println(
                "Precio total de los electrodomésticos: " + precioTotalElectrodomesticos);
        System.out.println(
                "Precio total de las lavadoras: " + precioTotalLavadoras);
    }
}
