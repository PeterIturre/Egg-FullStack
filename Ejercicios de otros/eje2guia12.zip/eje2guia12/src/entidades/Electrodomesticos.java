
package entidades;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public abstract class Electrodomesticos {

    protected double precio;
    protected String color;
    protected Character consumoEnergético; //(letras entre A y F)
    protected double peso;

    public Electrodomesticos() {
    }

    public Electrodomesticos(double precio, String color, char consumoEnergético, double peso) {
        this.precio = precio;
        this.color = color;
        this.consumoEnergético = consumoEnergético;
        this.peso = peso;
    }

    public double getPrecio() {
        return precio;
    }

    public String getColor() {
        return color;
    }

    public char getConsumoEnergético() {
        return consumoEnergético;
    }

    public double getPeso() {
        return peso;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setConsumoEnergético(char consumoEnergético) {
        this.consumoEnergético = consumoEnergético;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void comprobarConsumoEnergetico(Character letra) {

        letra = Character.toUpperCase(letra);
        if (letra >= 'A' && letra <= 'F') {
            consumoEnergético = letra;
        } else {
            consumoEnergético = 'F';
        }

    }

    public void comprobarColor(String color) {

        ArrayList<String> colores = new ArrayList(Arrays.asList("blanco", "negro", "rojo", "azul", "gris"));

        if (colores.contains(color.toLowerCase())) {
            this.color = primerLetraMayuscula(color);
        } else {
            this.color = "Blanco";
        }
    }

    public String primerLetraMayuscula(String palabra) {
        return palabra.substring(0, 1).toUpperCase() + palabra.substring(1, palabra.length());
    }

    public void crearElectrodomestico() {

        Scanner sc = new Scanner(System.in).useDelimiter("\n");

        //System.out.println("Ingresar precio"); 
        this.precio = 1000;
        System.out.println("Ingresar color");
        comprobarColor(sc.nextLine());
        System.out.println("Ingresar consumo");
        comprobarConsumoEnergetico(sc.next().charAt(0));
        System.out.println("Ingresar peso");
        this.peso = sc.nextDouble();

        precioFinal();
    }

    public double precioFinal() {

        switch (consumoEnergético) {
            case 'A':
                precio += 1000;
                break;
            case 'B':
                precio += 800;
                break;
            case 'C':
                precio += 600;
                break;
            case 'D':
                precio += 500;
                break;
            case 'E':
                precio += 300;
                break;
            case 'F':
                precio += 100;
                break;
        }

        precio = (peso >= 1 && peso <= 19) ? precio += 100 : precio;
        precio = (peso > 19 && peso <= 49) ? precio += 500 : precio;
        precio = (peso > 49 && peso <= 79) ? precio += 800 : precio;
        precio = (peso > 79) ? precio += 1000 : precio;
        
        return precio;

    }

    @Override
    public String toString() {
        return "Electrodomesticos{" + "precio=" + precio + ", color=" + color + ", consumoEnerg\u00e9tico=" + consumoEnergético + ", peso=" + peso + '}';
    }

}
