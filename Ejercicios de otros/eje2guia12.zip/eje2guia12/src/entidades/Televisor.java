/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Televisor extends Electrodomesticos {

    protected int resolucion;
    protected boolean sintonizadorTDT;

    public Televisor() {
    }

    public Televisor(int resolucion, boolean sintonizadorTDT) {
        this.resolucion = resolucion;
        this.sintonizadorTDT = sintonizadorTDT;
    }

    public Televisor(int resolucion, boolean sintonizadorTDT, double precio, String color, char consumoEnergetico, double peso) {
        super(precio, color, consumoEnergetico, peso);
        this.resolucion = resolucion;
        this.sintonizadorTDT = sintonizadorTDT;
    }

    public int getResolucion() {
        return resolucion;
    }

    public void setResolucion(int resolucion) {
        this.resolucion = resolucion;
    }

    public boolean hasSintonizadorTDT() {
        return sintonizadorTDT;
    }

    public void setSintonizadorTDT(boolean sintonizadorTDT) {
        this.sintonizadorTDT = sintonizadorTDT;
    }

    public void crearTelevisor() {

        Scanner scanner = new Scanner(System.in).useDelimiter("\n");

        System.out.print("Ingrese la resolución del televisor en pulgadas: ");
        resolucion = scanner.nextInt();

        System.out.print("¿Tiene sintonizador TDT incorporado? (true/false): ");
        sintonizadorTDT = scanner.nextBoolean();

        super.crearElectrodomestico();

    }

    @Override
    public double precioFinal() {
        double preciot = super.precioFinal();

        if (resolucion > 40) {
            preciot += preciot * 0.3;
        }
        
        if (sintonizadorTDT) {
            preciot += 500;
        }

        return preciot;
    }
}
