/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicio;



/**
 *
 * @author Usuario
 */
public interface IcalculoFormas {
    
    public void calcularArea();
    public void calcularPerimetro();
    
    public final double PI=Math.PI;
}
